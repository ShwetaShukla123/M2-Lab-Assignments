import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  /*test(){
  alert('Your ID is : '+this.UID);
  }
  salary()
  {
  let total  = (+this.Basic) + (+this.HRA) + (+this.DA) - (-this.Tax);
  alert("Your Gross Salary is : "+total);
  this.result = total;
  }*/
  /*PID:number;
  Pname:string;
  Pcost:number;
  Ponline:string;
  big="Big Bazar";
  d_M="D Mart";
  ril = "Reliance";
  mega = "Mega Mart";
  Pmart:boolean;
  Dmart:boolean;
  Rmart : boolean;
  Mmart : boolean;
  label:string;
  product(){

  if((this.Pname==undefined) ||(this.PID)==undefined || (this.Ponline)==undefined ||
   (this.Pcost)==undefined)
    alert("One or more fields are empty");

  if(this.Pmart==true)
  document.getElementById("big").innerHTML="Big Bazar";

  if(this.Dmart==true)
  document.getElementById("d").innerHTML="D Mart";

  if(this.Rmart==true)
  document.getElementById("r").innerHTML="Reliance";

  if(this.Mmart==true)
  document.getElementById("r").innerHTML="Mega Mart";
  }*/

  // Ename:string;
  // Ebasic:number;
  // Eda:number;
  // Ehra:number;
  // Ededuction:number;
  // EIncomeTax:number;
  // salary:number = 0;

  // test(){
  //   this.salary=(this.Ebasic + this.Ehra + this.Eda) - (this.Ededuction + this.EIncomeTax);
  //   alert('Employee Salary is : '+this.salary);
  //}
  // namesArray = ["Shweta", "Prerna", "John"];
  // name1:string;
  // addNames(){
  //   this.namesArray.push(this.name1);
  //   console.log(this.namesArray);
  // }
  displayName(name:string){
    alert("Here is a news "+name);
  }
}