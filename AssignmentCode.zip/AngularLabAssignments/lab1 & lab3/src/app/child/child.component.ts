import { Component, OnInit, Input, Output } from '@angular/core';
import { EventEmitter } from 'protractor';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
  // @Input() namesList:string[];
  @Output() outputObj = new EventEmitter();
  data:string= "Salman Khan's Nephew passes away";
  constructor() { }

  ngOnInit(): void {
  }
  sendData(){
    this.outputObj.emit(this.data);
  }

}
