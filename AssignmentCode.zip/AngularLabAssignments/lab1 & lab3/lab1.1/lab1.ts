class Mobile{
	mobileId: number;
    mobileName:string;
	mobileCost: number;
    constructor(id:number, name:string, cost:number){
        this.mobileId=id;
		this.mobileName= name;
		this.mobileCost=cost;
    } 
}

class BasicPhone extends Mobile{
    mobileType : string;
    constructor(id:number, name:string, cost: number, mobileType:string){
        super(id, name, cost);
        this.mobileType=mobileType;
    }
}

class SmartPhone extends Mobile{
    mobileType : string;
    constructor(id:number, name:string, cost: number, mobileType:string){
        super(id, name, cost);
        this.mobileType=mobileType;
    }
}

class Test{
	display(){
		let mobObj1 = new BasicPhone(3122, "Nokia",1500, "keypad");
		let mobObj2 = new SmartPhone(6478, "Samsung Galaxy M31", 15999, "Smartphone");
		console.log("Mobile 1 Details: ");
		console.log("Mobile id: "+mobObj1.mobileId);
		console.log("Mobile name: "+mobObj1.mobileName);
		console.log("Mobile Cost: "+mobObj1.mobileCost);
		console.log("Mobile Type: "+mobObj1.mobileType);
		
		console.log("\nMobile 2 Details: ");
		console.log("Mobile id: "+mobObj2.mobileId);
		console.log("Mobile name: "+mobObj2.mobileName);
		console.log("Mobile Cost: "+mobObj2.mobileCost);
		console.log("Mobile Type: "+mobObj2.mobileType);
    }

}
let testObj = new Test();
testObj.display();
