import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Observable,Subject } from "rxjs";  
import { Product } from '../product';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  constructor(private productservice : ProductService) { }
  productsArray: any[] =[]; 
  dtTrigger: Subject<any>= new Subject();  
  
  products: Observable<Product[]>;  
  product : Product=new Product();  
  productlist:any;       
   
  ngOnInit(): void { 
    this.productservice.getProductList().subscribe(
      data=>{
        this.products=data;
        this.dtTrigger.next();
      }
    )
  }

}
