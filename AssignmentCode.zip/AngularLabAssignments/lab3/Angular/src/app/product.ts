export class Product {
    productId: number;
    productName: string;
    price: number;
}
