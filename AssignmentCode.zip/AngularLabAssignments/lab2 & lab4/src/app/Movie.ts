export class Movie{
    name:string;
    rating:number;
    genre:string;
    constructor(name:string, rating:number, genre:string){
        this.name=name;
        this.rating=rating;
        this.genre=genre;
    }
}