import { Component, OnInit } from '@angular/core';
import { Movie } from '../Movie';
import { MovieService } from '../movie.service';

@Component({
  selector: 'app-add-movie',
  templateUrl: './add-movie.component.html',
  styleUrls: ['./add-movie.component.css']
})
export class AddMovieComponent implements OnInit {
  name:string;
  rating:number;
  genre:string;
  
  constructor(private movieService: MovieService) { }

  ngOnInit(): void {
    
  }
  addMovie(){
    let movie:Movie = new Movie(this.name, this.rating, this.genre);
    this.movieService.addMovie(movie);
  }

}
