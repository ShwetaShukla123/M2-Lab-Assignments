import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ChildComponent } from './child/child.component';
import {FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HighlightDirective } from './highlight.directive';
import {reverseString} from './reverseString.pipe';
import {DBServiceService} from './dbservice.service';
import { ProductListComponent } from './product-list/product-list.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { AddMovieComponent } from './add-movie/add-movie.component';
import { SearchMovieComponent } from './search-movie/search-movie.component';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
//import { MatSortHeaderIntl } from '@angular/material/sort';

const routes:Routes=[
  {path:'ProductListAll', component:ProductListComponent},
  {path:'ProductListAll/:id', component:ProductListComponent},
  {path:'ContactUs', component:ContactUsComponent},
  {path:'AddMovie', component:AddMovieComponent},
  {path:'', component:HomeComponent},
  {path:'SearchMovie', component:SearchMovieComponent},

];
@NgModule({
  declarations: [
    AppComponent,
    ChildComponent,
    HighlightDirective,
    reverseString,
    ProductListComponent,
    AddMovieComponent,
    SearchMovieComponent,
    ContactUsComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes),
  //  MatSortHeaderIntl
  ],
  providers: [DBServiceService,],
    // MatSortHeaderIntl
  bootstrap: [AppComponent]
})
export class AppModule { }
