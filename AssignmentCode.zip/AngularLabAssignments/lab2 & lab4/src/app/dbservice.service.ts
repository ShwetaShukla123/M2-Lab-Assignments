import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DBServiceService {

  constructor() { }

  insert(){
    alert("Record inserted successfully" );
  }
  update(){
    alert("Record updated successfully" );
  }
  delete(){
    alert("Record deleted successfully" );
  }
  displayAll(){
    alert("Record displayed successfully" );
  }
}
