import { Component, OnInit } from '@angular/core';
import { MovieService } from '../movie.service';
import { Movie } from '../Movie';

@Component({
  selector: 'app-search-movie',
  templateUrl: './search-movie.component.html',
  styleUrls: ['./search-movie.component.css']
})
export class SearchMovieComponent implements OnInit {
  searchMovieList: Movie[]=[];
  movies: Movie[];

  constructor(private movieService: MovieService) { }
  genre:string;

  ngOnInit(): void {
    this.movies = this.movieService.getMovies();
    this.movieService.moviesChanged.subscribe(
      (movie: Movie[])=>{
        this.movies = movie;
      }
    )

  }
  onSearch(){
    for(var i in this.movies){
      if(this.movies[i].genre===this.genre){
        this.searchMovieList.push(this.movies[i]);
      }
    }
  }
}
