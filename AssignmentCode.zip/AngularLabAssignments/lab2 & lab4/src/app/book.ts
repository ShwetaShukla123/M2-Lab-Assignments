export class Book{

    constructor(private id:number,private name:string){}
}