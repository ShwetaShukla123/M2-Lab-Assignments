import { Injectable, EventEmitter } from '@angular/core';
import { Movie } from './Movie';

@Injectable({
  providedIn: 'root'
})
export class MovieService {

  moviesChanged = new EventEmitter<Movie[]>();

  movieList: Movie[]=[
    new Movie("SpotLight",4.0, "Drama"),
    new Movie("True Story",4.2, "Drama"),
    new Movie("3 Idiots",4.1, "Commedy"),
    new Movie("Dhamaal",4.0, "Commedy"),
    new Movie("The Martian",4.3, "Fiction"),
    new Movie("Intersteller",4.4, "Fiction")
  ];
  constructor() { }
  getMovies(){
    return this.movieList.slice();
  }
  addMovie(movie: Movie){
    this.movieList.push(movie);
    this.moviesChanged.emit(this.movieList.slice());
  }
}
