import { Component, OnInit } from '@angular/core';
import { Product } from '../Product';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  productList: Product[] = 
  [{productId:101, productName:'Samsung TV', productCost:25000},
  {productId:102, productName:'LG TV', productCost:35000},
  {productId:103, productName:'Sony TV', productCost:45000}
];
  id:number;

  constructor(private route: ActivatedRoute) {
    route.params.subscribe(params=>{this.id=params['id'];});
    if(this.id != undefined){
      let id = this.id;
      this.productList = this.productList.filter(function (user)
      {
        return user.productId==id;
      });
    }
   }
  sortById() {
    this.productList.sort((a,b) => (a.productId - b.productId));
  }

  sortByName() {
    this.productList.sort(
      function(a, b){
        var n1 = a.productName.toUpperCase(),n2 = b.productName.toUpperCase();
        if(n1 <n2)
          return -1
        else if(n1 > n2)
          return 1;
        else return 0;
      }
    )
  }

  sortByCost() {
    this.productList.sort((a,b) => (a.productCost - b.productCost));
  }

  ngOnInit(): void {
  }

}