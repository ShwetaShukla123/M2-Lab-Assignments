import { Component, Injectable } from '@angular/core';
import { Employee } from './Employee';
import { reverseString } from './reverseString.pipe';
import { DBServiceService } from './dbservice.service';
import {Sort} from '@angular/material/sort';
import { Book } from './book';
import { HttpClient } from '@angular/common/http';
import { Movie } from './Movie';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent /*extends reverseString*/{
  title = 'AngularApp';
  // displayName(name:string){
  //   alert("Hey I am learning "+name);
  // }
  id:string;
  name:string;
  salary:number;
  department:string;
  editindex:number;
  editEmployee:Employee;
  public addingform = true;

  empList:Employee[] = [
    new Employee("123","Shweta", 50000,"CSE")
    
  ];
  addEmployee(){
    let emp:Employee = new Employee(this.id, this.name, this.salary, this.department);
    this.empList.push(emp);
  }
  deleteEmployee(index:number){
    this.empList.splice(index, 1);
  }

  addEditedEmployee(){
    this.empList.splice(this.editindex, 1);
    let emp1:Employee = new Employee(this.editEmployee.id, this.name, this.salary, this.department);
    this.empList.push(emp1);
    (<HTMLInputElement> document.getElementById("submitButton")).disabled = false;
    (<HTMLInputElement> document.getElementById("editButton2")).disabled = true;
    this.addingform = true;
    document.getElementById("heading").innerHTML="Add Employee";
  }
  updateEmployee(index:number, emp:Employee){
    (<HTMLInputElement> document.getElementById("editButton2")).disabled = false;
    (<HTMLInputElement> document.getElementById("submitButton")).disabled = true;
    document.getElementById("heading").innerHTML="Edit Employee";
    this.addingform = false;
    // let i = (document.getElementById("empform"));
    // i.removeChild(i.firstElementChild);
    (document.getElementById("name") as HTMLTextAreaElement).value="";
    (document.getElementById("salary") as HTMLTextAreaElement).value="";
    (document.getElementById("department") as HTMLTextAreaElement).value="";
    this.editindex=index;
    this.editEmployee=emp;
  }
  
  //stringDataForPipe:string="Hello, how are you..";
  /*constructor(private myDbService: DBServiceService){
    super();
  }
  displayData(){
    alert("Inside Display Data");
    this.myDbService.insert();
    this.myDbService.update();
    this.myDbService.delete();
    this.myDbService.displayAll();
  }*/
  /*booksList:any=[];
  book:Book;
  errorMsg:string;
  id:number;
  searchid:number;
  searchBookname:string;
  stringifiedData: any;
  flag = false;

  constructor(private HttpClient:HttpClient){

  }
  ngOnInit(){
    this.HttpClient.get("assets/data/books.json").subscribe(
      data =>{
        console.log(data);
        this.booksList=data;
      },
      (error)=>{
        this.errorMsg=error.message;
        alert(this.errorMsg);
      }
    ); 
  }
  searchById(){
     
    for(var i in this.booksList){
      this.stringifiedData = JSON.stringify(this.booksList[i]); 
      let obj: MyObj= JSON.parse(this.stringifiedData);
      if(obj.id==this.id){
        this.searchid=obj.id;
        this.searchBookname=obj.name;
        this.flag = true;
      }
      break;
    }
  }
//}
interface MyObj {
  id: number;
  name: string;
}*/

}