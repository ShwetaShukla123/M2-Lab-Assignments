export class Employee{
    id: string;
    name:string;
    salary:number;
    department:string;
    constructor(id:string, name:string, sal:number, dept:string){
        this.id=id;
        this.name=name;
        this.salary=sal;
        this.department=dept;
    }
}